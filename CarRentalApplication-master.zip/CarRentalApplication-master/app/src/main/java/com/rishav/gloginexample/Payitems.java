package com.rishav.gloginexample;

public class Payitems {
public String Name,Seater,Locdest,Locsrc,Imgid,RupeesperHour,InitialRs,Totalprice,Date,Time,Hours;

    public Payitems(String name, String seater, String locdest, String locsrc, String imgid, String rupeesperHour, String initialRs, String totalprice, String date, String time,String Hours) {
        this.Name = name;
        this.Seater = seater;
        this.Locdest = locdest;
        this.Locsrc = locsrc;
        this.Imgid = imgid;
        this.RupeesperHour = rupeesperHour;
        this.InitialRs = initialRs;
        this.Totalprice = totalprice;
        this.Date = date;
        this.Time = time;
        this.Hours = Hours;
    }


}