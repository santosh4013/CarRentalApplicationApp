package com.rishav.gloginexample;

public class License {

    public String LicenseId;

    public License(String pan) {
        this.LicenseId = pan;
    }

}
